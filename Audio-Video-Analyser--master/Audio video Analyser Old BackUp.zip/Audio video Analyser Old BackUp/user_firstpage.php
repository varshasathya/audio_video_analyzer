<?php

require 'config.php';
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<title>Page Title</title>

<style>

.btn {
	letter-spacing: 1px;
	text-decoration: none;
	background: none;
    -moz-user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 0;
    cursor: pointer;
    display: inline-block;
    margin-bottom: 0;
    vertical-align: middle;
    white-space: nowrap;
	font-size:14px;
	line-height:20px;
	font-weight:700;
	text-transform:uppercase;
	border: 3px solid;
	padding:8px 20px;
}

.btn-outlined {
    border-radius: 0;
    -webkit-transition: all 0.3s;
       -moz-transition: all 0.3s;
            transition: all 0.3s;
}

.btn-outlined.btn-theme {
    background: none;
    color: #6f5499;
	border-color: #6f5499;
}

.btn-outlined.btn-theme:hover,
.btn-outlined.btn-theme:active {
    color: #FFF;
    background: #6f5499;
    border-color: #6f5499;
}

.btn-outlined.btn-black {
    background: none;
    color: #000000;
	border-color: #000000;
}

.btn-outlined.btn-black:hover,
.btn-outlined.btn-black:active {
    color: #FFF;
    background: #000000;
    border-color: #000000;
}

.btn-outlined.btn-white {
    background: none;
    color: #FFFFFF;
	border-color: #FFFFFF;
}

.btn-outlined.btn-white:hover,
.btn-outlined.btn-white:active {
    color: #6f5499;
    background: #FFFFFF;
    border-color: #FFFFFF;
}

.btn-xs{
	font-size:11px;
	line-height:14px;
	border: 1px solid;
	padding:5px 10px;
}

.btn-sm{
	font-size:12px;
	line-height:16px;
	border: 2px solid;
	padding:8px 15px;
}

.btn-lg{
	font-size:18px;
	line-height:22px;
	border: 4px solid;
	padding:13px 40px;
}
</style>
</head>
<!------ Include the above in your HEAD tag ---------->

<div class="container">
	
</div>
<?php
require 'config.php';
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$userid=$_SESSION["userid"];

$sql="select breakdown_id,video_name from upload_video where userid= '{$userid}'";
$result = $conn->query($sql);

echo " <a href='https://sindiah.000webhostapp.com/Sih_Project/Sih/home_upload.php' class='btn btn-outlined btn-theme '   data-wow-delay='0.7s'>New video</a>";


if ($result->num_rows > 0) {
   
    while($row = $result->fetch_assoc()) {
       // echo 'https://sindiah.000webhostapp.com/Sih_Project/Sih/upload/'.$row["video_name"]."<br>";
      // echo "<video src='https://sindiah.000webhostapp.com/Sih_Project/Sih/upload/".$row['video_name']."' alt=Uploaded any thing to analyse' id='edit-save' style='height:450px;width:100%;' ></video>";
       //echo "\n\n";
	   $video_url="https://sindiah.000webhostapp.com/Sih_Project/Sih/upload/".$row['video_name'];
	   $button_url='https://sindiah.000webhostapp.com/Sih_Project/Sih/display_component.php?breakdown='.$row['breakdown_id'].'&videourl='.$video_url;
	   echo "<div >
		<video  src=".$video_url." alt='Uploaded'  id='edit-save' width='320' height='240' ></video>
		<p >
            <a href=".$button_url." class='btn btn-outlined btn-theme'   data-wow-delay='0.7s'>".$row['video_name']."</a>
        </p>
		</div>";
    }
} else {
    echo "0 results";
}
/*for ($x = 0; $x < $row_count; $x++) {

 echo $rows[video_name];
}*/



?>