<?php
// This sample uses the Apache HTTP client from HTTP Components (http://hc.apache.org/httpcomponents-client-ga/)
require_once 'HTTP/Request2.php';
$breakdownid=$_POST["breakdown"];
$faceid=$_POST["id"];
$new_name=$_POST["name"];
//print_r($_POST);
$request = new Http_Request2('https://videobreakdown.azure-api.net/Breakdowns/Api/Partner/Breakdowns/UpdateFaceName/'.$breakdownid.'?faceId='.$faceid.'&newName='.$new_name);
//$str='https://videobreakdown.azure-api.net/Breakdowns/Api/Partner/Breakdowns/UpdateFaceName/'.$breakdownid.'?faceId='.$faceid.'&newName='.$new_name.'';
//print_r($str);
$url = $request->getUrl();

$headers = array(
    // Request headers
    'Ocp-Apim-Subscription-Key' => 'b99be3af54e147b49ee8c6412198fda2',
);

$request->setHeader($headers);



//$url->setQueryVariables($parameters);

$request->setMethod(HTTP_Request2::METHOD_PUT);

// Request body

try
{
    $response = $request->send();
    echo $response->getBody();
}
catch (HttpException $ex)
{
    echo $ex;
}

?>