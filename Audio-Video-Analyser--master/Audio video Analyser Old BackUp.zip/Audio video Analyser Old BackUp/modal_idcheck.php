<?php
if(isset($_POST["verifyid"]))
{
    $a="1";
    $id=$_POST["verifyid"];
    require 'config.php';
    $conn = new mysqli($servername, $username, $password, $dbname);
    $smt=$conn->prepare("update users set activation= ? where u_id= ? ");
    $smt->bind_param('ss',$a,$id);
    $smt->execute();
    echo "<script>alert('Account Verified! Login to Continue...');</script>";
    echo "<script>window.location.href='login.php';</script>";
    
}
?>

<!DOCTYPE html>
<html>
<head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <title>Verify your Account</title></head>
<body>
    <div class="container-fluid">
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
  Click Here To Verify
</button>

<!-- The Modal -->
<div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Enter Your ID to Activate Your Account</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="" method="post">
            <input type="text" name="verifyid" class="form-control" placeholder="Enter the ID sent to your mail"/>
            </br>
            <button type="submit" class="btn btn-success">Activate</button>
        </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>    
</div>
</body>