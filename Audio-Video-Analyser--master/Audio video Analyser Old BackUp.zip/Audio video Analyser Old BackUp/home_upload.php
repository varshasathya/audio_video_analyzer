<?php
 header('Access-Control-Allow-Origin: *'); 
if(!isset($_FILES['fileToUpload'])) {
  echo <<<eoa
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Demo</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="progressbar.js"></script>
  
</head>
<body style="background-color: beige;">

<div class="container-fluid" style="background-color: beige;">
  <h1 style="background-color:#4caf4f;">SIH</h1>
  
  <div class="row">
    <div class="col-sm-12" style="">

    <form action='' method='post' enctype='multipart/form-data' id='form'>
    <div class="form-group">
      <label for="email">SUBMIT FILE HERE:</label>
      <input type="file" name='fileToUpload' id="fileToUpload" onchange="uploadFile()" class="form-control" id="email" placeholder="Enter email">
    </div>
	<progress id="progressBar" value="0" max="100" style="width:300px;"></progress>
	<p id="loaded_n_total"></p><br/>
	<p id="status"></p>
	<br/>
    <button type="submit" class="btn btn-default submitbtn">Submit & Analyse</button>
  </form>
    </div>
  </div>
  
  <br/>
  <div class="row">
    <div class="col-sm-6" style="background-color:lightgrey;">
    <p><b>EXTRACTED DATA:</b></p>
    <textarea id="responseTextArea" class="UIInput" style="width:100%; height:500px;overflow:scroll"></textarea>
    
    </div>
    <div class="col-sm-6" style="background-color:pink;">
      <p><b>Response</b></p>
      <video src="" alt="Upload the Video to be analysed" style="height:600px;width:100%;"></video>
      </div>
  </div>
</div>
 </body>
</html>
eoa;


 exit;
}

if(isset($_FILES['fileToUpload'])){
$target_dir = "upload/";
$target_file = $target_dir.str_replace(" ",'_',basename( $_FILES["fileToUpload"]["name"]));

$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));


if(isset($_POST["submit"])) {
    $check = $_FILES['fileToUpload']['size'];
    if($check !== false) 
        $uploadOk = 1;
    else 
        $uploadOk = 0;
}


$path_parts = pathinfo($_FILES["fileToUpload"]["name"]);
$imageFileType = $path_parts['extension'];
if($imageFileType != "mp4" && $imageFileType != "MP4"  ) 
    $uploadOk = 0;


if ($uploadOk == 0) {
   
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
         //echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } 
}

$src="https://sindiah.000webhostapp.com/Sih_Project/Sih/{$target_file}";
//echo $src;

require_once "./x.php";

$apidata= json_decode(breakdown($src));


echo <<<eoa
<!DOCTYPE html>
<html lang="en">
<head>
  <title>SIH</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="pretty.js"></script>
  
</head>
<body style="background-color: beige;">

<div class="container-fluid" style="background-color: beige;">
  <h1 style="background-color:#4caf4f;">Sih</h1>
  
  <div class="row">
    <div class="col-sm-12" style="">

    <form action='' method='post' enctype='multipart/form-data' id='form'>
    <div class="form-group">
      <label for="email">SUBMIT FILE HERE:</label>
      <input type="file" name='fileToUpload' class="form-control" id="email" placeholder="Enter email">
    </div>
    <progress id="progressBar" value="0" max="100" style="width:300px;"></progress>
	<p id="loaded_n_total"></p><br/>
	<p id="status"></p>
    <br/>
    <button type="submit" class="btn btn-default submitbtn">Submit & Analyse</button>
  </form>
    </div>
  </div>

  
  <br/>
  <div class="row">
    <div class="col-sm-6" style="background-color:lightgrey;">
    <p><b>EXTRACTED DATA:</b></p>
    <div id="responseTextArea" class="UIInput" style="width:100%; height:500px;overflow:scroll"></div>
    
    </div>
    <div class="col-sm-6" style="background-color:pink;">
      <p><b>Response:</b></p>
      <video src="" alt="Uploaded any thing to analyse" id='edit-save' style="height:450px;width:100%;" controls></video><br/>
      </div>
  </div>
</div>
eoa;

$dta=$apidata;


echo '
<script>
 var edit_save = document.getElementById("edit-save");
    edit_save.src = "'.$src.'";
   try {
   
   var meta="'.stripslashes($dta).'";


var jsoon=prettyPrint(meta, {
		// Config
		maxArray: 20, // Set max for array display (default: infinity)
		expanded: false, // Expanded view (boolean) (default: true),
		maxDepth: 5 // Max member depth (when displaying objects) (default: 3)
	})
	
$("#responseTextArea").append(jsoon) ;}
catch(err){
    
    $("#responseTextArea").text("Error occurred!") ;
}

  var clr =setInterval(function() {
        
        $.ajax({
            url: "update.php?id='.$dta.'"
            ,
            type: "GET",
            
        })
        .done(function(data) {
        
        var dat=JSON.parse(data)
        if(dat["breakdowns"][0]["processingProgress"].localeCompare("100%")==0)
        {
            StopIt();
        }
           jsoon= prettyPrint(dat, {
		// Config
		maxArray: 20, // Set max for array display (default: infinity)
		expanded: false, // Expanded view (boolean) (default: true),
		maxDepth: 5 // Max member depth (when displaying objects) (default: 3)
	})
	
$("#responseTextArea").html(jsoon) ;
        })
        .fail(function() {
            alert("error");
        });
    }, 20000);
    
    
    
    function StopIt() {
    clearTimeout(clr);
}
</script>
 </body>
</html>';


//print_r(json_encode($dta));
}
?>