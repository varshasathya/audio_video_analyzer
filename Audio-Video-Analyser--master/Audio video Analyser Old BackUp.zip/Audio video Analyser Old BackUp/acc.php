<?php
$uname=$_POST["uname"];
$pass=$_POST["psw"];
$mobile=$_POST["mobile_no"];
$mail=$_POST["email"];
$state=$_POST["state"];
$activation="0";
require 'config.php';
$con = new mysqli($servername, $username, $password, $dbname);

$smt=$con->prepare("select * from users where u_mail=?");
$smt->bind_param('s',$mail);
$smt->execute();
$res=$smt->get_result();
if($row=$res->fetch_assoc())
{
    echo '<script>window.alert("Email already found!   Select another mail ID!");</script>';
    echo "<script>window.location.href='signup.php';</script>";
}
else{
    
$smt=$con->prepare("insert into users(u_name,u_password,u_mobile,u_mail,u_state,activation) values(?,?,?,?,?,?)");
$smt->bind_param('ssssss',$uname,$pass,$mobile,$mail,$state,$activation);
$smt->execute();
$smt=$con->prepare("select * from users where u_mail=?");
$smt->bind_param('s',$mail);
$smt->execute();

$res=$smt->get_result();
$row=$res->fetch_assoc();
$mail_content="Your Account activation key is  ".$row["u_id"].". Please verify this to activate your account.";
$mail_subject="Activate Your Account";
require 'test.php';
send_mqil_using_php_mailer($mail,$mail_content,$mail_subject);
echo '<script>window.alert("Account created successfully!   Please Check Your Mail and verify to continue!");</script>';
echo "<script>window.location.href='modal_idcheck.php';</script>";
}
$con->close();