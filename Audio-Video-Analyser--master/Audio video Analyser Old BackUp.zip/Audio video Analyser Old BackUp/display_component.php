<?php
 header('Access-Control-Allow-Origin: *'); 
// muhamed salih - for display json and video
$break=$_GET['breakdown'];
$src=$_GET['videourl'];
require "./x.php";
$dta=breakdown_id_to_json($break);

//print_r( $_GET);
echo <<<eoa
<!DOCTYPE html>
<html lang="en">
<head>
  <title>SIH</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="pretty.js"></script>
  <script src="progressbar.js"></script>
  <style>
  #facesbutton{
      display:none;
  }
  </style>
</head>
<body style="background-color: beige;">

<div class="container-fluid" style="background-color: beige;">
  <h1 style="background-color:#4caf4f;">Sih</h1>
  
  
  <br/>
  <div class="row">
    <div class="col-sm-6" style="background-color:lightgrey;">
    <p><b>EXTRACTED DATA:</b></p>
    <div id="responseTextArea" class="UIInput" style="width:100%; height:500px;overflow:scroll"></div>
    
    </div>
    <div class="col-sm-6" style="background-color:pink;">
      <p><b>Response:</b></p>
      <video src="" alt="Uploaded any thing to analyse" id='edit-save' style="height:450px;width:100%;" controls></video><br/>
      </div>
  </div>
</div>
eoa;




echo '
<script>
var dat;

 var edit_save = document.getElementById("edit-save");
    edit_save.src = "'.$src.'";
   try {
   
   var meta='.stripslashes($dta).';


var jsoon=prettyPrint(meta, {
		// Config
		maxArray: 20, // Set max for array display (default: infinity)
		expanded: false, // Expanded view (boolean) (default: true),
		maxDepth: 5 // Max member depth (when displaying objects) (default: 3)
	})
	
$("#responseTextArea").append(jsoon) ;}
catch(err){
    
    $("#responseTextArea").text("Error occurred!") ;
}


</script>
 </body>
</html>';

?>