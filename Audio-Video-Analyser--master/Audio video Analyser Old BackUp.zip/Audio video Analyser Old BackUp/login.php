<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #f1f1f1;}
body {
    background-color:#92a8d1;
}
div{
text-align:center
}
</style>
</head>
<body>
<h2>WELCOME!</h2>

<form action="val.php" method="post">
    
 <div class="container">
      <label for="uname"><b>Username</b></label> 
      <input type="text" placeholder="Enter Email" name="umail" required> <br/><br/>

      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="pass" required> <br/><br/>
      <button type="submit">Login</button>
      </form>
      
	<a href="signup.php">signup</a>

 </div>

<!---<style>
text-align:center

    <button type="button" class="cancelbtn">Cancel</button>
</p> 
<p>  
 <span class="psw">Forgot <a href="#">password?</a></span>
  </p> --->

</body>
</html>