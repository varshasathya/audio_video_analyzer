<?php
$servername = "localhost";
$username = "id5040077_root";
$password = "12345";
$dbname = "id5040077_sih_2018";

?>