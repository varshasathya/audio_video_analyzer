<?php
//Get BreakDown Code + outputjson using url
require_once 'HTTP/Request2.php';

function breakdown($body){
$request = new Http_Request2('https://videobreakdown.azure-api.net/Breakdowns/Api/Partner/Breakdowns?name=a&privacy=Public&videoUrl='.$body.'&language=en-US');

$url = $request->getUrl();

$headers = array(
    'Ocp-Apim-Subscription-Key' => 'b99be3af54e147b49ee8c6412198fda2',
);

$request->setHeader($headers);
$request->setMethod(HTTP_Request2::METHOD_POST);

try{
    $response = $request->send();
    //echo $response->getBody();
    return $response->getBody(); 
}
catch (HttpException $ex){
    echo $ex;
    //return $ex;
}
}

//get the processing status using breakdown id
function process($code){
    $code=substr($code, 1, -1);
  $link='https://videobreakdown.azure-api.net/Breakdowns/Api/Partner/Breakdowns/'.$code.'/State';
  //echo $link;
$request = new Http_Request2($link);
$url = $request->getUrl();

$headers = array(
    // Request headers
    'Ocp-Apim-Subscription-Key' => 'b99be3af54e147b49ee8c6412198fda2',
);

$request->setHeader($headers);

$request->setMethod(HTTP_Request2::METHOD_GET);

// Request body
//$request->setBody("{body}");

try
{
    $response = $request->send();
    return $response->getBody();
}
catch (HttpException $ex)
{
    echo $ex;
}
}



//get the data using breakdown id
function breakdown_id_to_json($break){
$link= 'https://videobreakdown.azure-api.net/Breakdowns/Api/Partner/Breakdowns/'.$break.'?language=en-US';
$request = new Http_Request2($link);
$url = $request->getUrl();

$headers = array(
    // Request headers
    'Ocp-Apim-Subscription-Key' => 'b99be3af54e147b49ee8c6412198fda2',
);

$request->setHeader($headers);

// $parameters = array(
//     // Request parameters
//     'language' => 'en-US',
// );

//$url->setQueryVariables($parameters);

$request->setMethod(HTTP_Request2::METHOD_GET);

// Request body
//$request->setBody("{body}");

try
{
    $response = $request->send();
    return $response->getBody();
}
catch (HttpException $ex)
{
    return $ex;
}

}
?>
