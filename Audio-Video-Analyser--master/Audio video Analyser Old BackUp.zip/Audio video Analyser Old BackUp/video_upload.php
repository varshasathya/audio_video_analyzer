<?php
require_once 'config.php';

$conn = new mysqli($servername, $username, $password, $dbname);
// Create connection
function upload_video($user_id,$breakdown_id,$video_name) {
$connection=$GLOBALS['conn'];
// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
} 

$sql = "INSERT INTO `upload_video` (`userid`, `breakdown_id` , `video_name`) VALUES ('{$user_id}', '{$breakdown_id}', '{$video_name}');";

if ($connection->query($sql) === TRUE) {
    return "success";
} else {
    return "failure";
}

$connection->close();
}
?>