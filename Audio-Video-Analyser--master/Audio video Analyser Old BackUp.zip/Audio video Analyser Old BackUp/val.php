<?php 
session_start();

require_once 'config.php';

$conn = new mysqli($servername, $username, $password, $dbname);

$u=$_POST['umail'];
$p=$_POST['pass'];


$row='';
$smt=$conn->prepare("select * from users where u_mail=? and u_password=? and activation=1");
$smt->bind_param('ss',$u,$p);
$smt->execute();
$result=$smt->get_result();
if($row =$result->fetch_assoc()){
    $_SESSION["userid"]=$row["u_id"];
	echo "<script>window.location.href='user_firstpage.php';</script>";

}

else
{       
        echo "<script>alert('Invalid credentials');</script>";
        echo "<script>window.location.href='login.php';</script>";
}
?>

